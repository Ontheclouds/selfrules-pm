<?php
$lang['event_invoice_overdue'] = 'Paiement de la facture {invoice_number} est <span class="label label-important"> retard </span>';
$lang['event_project_overdue'] = 'Projet {project_number} délai <span class="label label-important">atteint</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning"> Nouvelle facture </span> nécessaire à la souscription {subscription_number}';

