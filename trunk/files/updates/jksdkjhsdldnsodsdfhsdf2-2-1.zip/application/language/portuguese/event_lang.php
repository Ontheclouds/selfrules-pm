<?php
$lang['event_invoice_overdue'] = 'Pagamento de fatura {invoice_number} está <span class="label label-important">atrasado</span>';
$lang['event_project_overdue'] = 'Projeto {project_number} <span class="label label-important">data final atingido</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Nova fatura</span> necessária para subscrição {subscription_number}';
