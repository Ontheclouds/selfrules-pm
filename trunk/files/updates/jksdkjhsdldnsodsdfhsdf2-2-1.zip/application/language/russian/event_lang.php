<?php
$lang['event_invoice_overdue'] = 'Оплата счета является {invoice_number} <span class="label label-important"> просроченной </span>';
$lang['event_project_overdue'] = 'Проект {project_number} <span class="label label-important"> срок достигла </span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Новая счет-фактура</span> необходимо для подписки {subscription_number}';

